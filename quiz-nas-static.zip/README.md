# 刷题小程序 - NAS 自托管版

前端为纯静态站点，可直接放到 NAS / 任意静态文件服务器；**共享试卷与多人成绩**需要同时运行内置的 Node 后端（Docker Compose 已包含）。

## 特性

- ✅ **静态优先**：不启动后端也能使用全部本地功能（题库、刷题、背题、收藏、组卷、考试记录）
- ✅ **共享试卷**：把试卷生成链接发给其他人，所有人成绩汇总在「共享试卷 → 考试记录」（需要后端）
- ✅ **Hash 路由**：刷新不会 404，不需要 nginx try_files 配置
- ✅ **相对路径**：部署到任意子目录都能正常加载 JS/CSS
- ✅ **内置题库**：开箱即用，内置示例题目
- ✅ **本地存储**：所有数据存在浏览器 localStorage，隐私安全
- ✅ **Excel 导入**：支持多 Sheet 合并、选择标题行、自定义列映射
- ✅ **刷题 / 背题**：顺序练习、随机练习、错题本、收藏题目，两种模式分别记录进度
- ✅ **试卷组卷**：智能组卷、在线考试、成绩统计
- ✅ **搜题功能**：全文关键词搜索

## 部署方式

### 方式一：直接放到 Web 目录

将本目录所有文件上传到 NAS 的 Web 服务目录（如 nginx 的 `html/quiz/`），浏览器访问对应地址即可。

> 此方式下所有数据都在本机浏览器中，**共享试卷功能不可用**（「共享试卷」页会提示服务未连接）。需要共享时请使用方式四。

### 方式二：nginx 配置示例

```nginx
server {
    listen 80;
    server_name your-nas.local;
    root /volume1/web/quiz-app;
    index index.html;

    # 静态资源缓存
    location /assets/ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # 因为用了 Hash 路由，所有路径都直接返回 index.html
    # 不需要 try_files，Hash 路由会自己处理
}
```

### 方式三：群晖 NAS

1. 打开「Web Station」
2. 新建基于「静态网页」的网站
3. 文档根目录选择本文件夹
4. 保存后访问对应地址即可

### 方式四：Docker Compose（推荐）

无需手动下载代码，也无需 git。`docker-compose.yml` 首次创建项目时会自动从 GitHub 下载仓库文件，提取静态站点写入 Docker 数据卷，之后启动、重启、重建容器都不会重复下载：

```bash
docker compose up -d
```

访问 `http://<设备IP>:8080`。如需修改端口：

```bash
PORT=9090 docker compose up -d
```

更新到最新版本（会强制重新下载）：

```bash
FORCE_UPDATE=1 docker compose up -d --force-recreate
```

如 GitHub 访问受限，可通过 `PROJECT_TARBALL_URL` 指定加速地址：

```bash
PROJECT_TARBALL_URL=https://gh-proxy.com/https://github.com/QQxiaobian/shuatibao/archive/refs/heads/main.tar.gz docker compose up -d --force-recreate
```

> `shuatibao-init` 是初始化容器，下载完成后会显示为「已停止 / Exited:0」，属于正常现象；实际提供网页服务的是 `shuatibao` 容器。

该模式下前端与 API 由同一个 Node 服务提供（`server/index.mjs`），共享试卷、考试记录保存在 `quiz-data` 数据卷的 `db.json` 中，重建容器不会丢失。备份时导出该卷即可。

## 功能说明

### 可用功能

- 📚 **题库管理**：查看、编辑、删除题目
- 📥 **Excel 导入**：支持 .xlsx/.xls，多 Sheet 合并，选择标题行，自定义列映射
- 📤 **Excel 导出**：一键导出当前题库为 Excel
- ✍️ **刷题练习**：顺序 / 随机 / 错题 / 收藏 四种模式
- 📖 **背题模式**：直接显示答案，可开启「只显示正确选项」专注记忆
- ⭐ **收藏题目**：重点题目标记收藏
- 📝 **错题本**：自动收集答错的题目
- 🔍 **搜题**：全文关键词搜索
- 📄 **试卷中心**：智能组卷、在线考试、成绩统计、试卷导出

### 不可用功能（NAS 自托管限制）

- ❌ **PDF / Word 文档解析导入**：需要云端 AI 插件支持，NAS 纯静态环境不可用
  - 替代方案：使用 Excel 导入（推荐），或手动添加题目

## 数据存储

所有数据存储在浏览器的 `localStorage` 中，包括：

- 题库题目数据
- 错题本记录
- 收藏题目
- 刷题进度
- 试卷配置和记录
- 搜索历史

⚠️ **注意**：清除浏览器数据会导致所有数据丢失，请定期使用「导出 Excel」功能备份题库。

## 浏览器兼容

- Chrome / Edge 90+
- Firefox 88+
- Safari 14+
- 移动端 iOS Safari / Chrome Android

## 更新方式

重新构建新版本后，替换静态文件即可。用户本地存储的题库数据不会丢失。
